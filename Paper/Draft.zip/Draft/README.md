# paper-skeleton

A minimal latex paper skeleton file for writing conference papers.

The Makefile requires "rubber", but you can easily change this to build with "pdflatex" instead.
